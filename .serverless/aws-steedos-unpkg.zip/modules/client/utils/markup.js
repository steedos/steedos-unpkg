export function createHTML(content) {
  return { __html: content };
}
