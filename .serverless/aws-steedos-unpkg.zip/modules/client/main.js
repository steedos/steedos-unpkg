import React from 'react';
import ReactDOM from 'react-dom';

import App from './main/App.js';

ReactDOM.render(<App />, document.getElementById('root'));
