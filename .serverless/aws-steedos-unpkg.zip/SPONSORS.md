<h1 align="center">Sponsors &amp; Backers</h1>

UNPKG is an open source project licensed under the AGPL. Ongoing development of UNPKG is made possible thanks to the support of our sponsors and backers.

If you'd like to support the project, please consider <a title="Support UNPKG on Patreon" href="https://www.patreon.com/unpkg">becoming a backer or sponsor on Patreon</a>.

<p>&nbsp;</p>

<h2 align="center">Key Sponsors</h2>

<p align="center">
  <a title="Angular" href="https://angular.io">
    <img alt="Angular Logo" src="./sponsors/angular.png" />
  </a>
</p>

<p align="center"><a title="Become a Key Sponsor on Patreon" href="https://www.patreon.com/unpkg">Become a Key Sponsor</a></p>

<p>&nbsp;</p>

<h2 align="center">Star Sponsors</h2>

<p align="center"><a title="Become a Star Sponsor on Patreon" href="https://www.patreon.com/unpkg">Become a Star Sponsor</a></p>

<p>&nbsp;</p>

<h2 align="center">Sponsors</h2>

<p align="center"><a title="Become a Sponsor on Patreon" href="https://www.patreon.com/unpkg">Become a Sponsor</a></p>

<p>&nbsp;</p>

<h2 align="center">Backers</h2>

<p align="center"><a title="Become a Backer on Patreon" href="https://www.patreon.com/unpkg">Become a Backer</a></p>
